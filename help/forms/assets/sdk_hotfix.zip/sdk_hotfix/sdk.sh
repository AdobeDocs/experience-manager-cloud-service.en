#!/bin/bash

## BEGIN CONFIGURABLE ENVIRONMENT VARIABLES ##
export AEM_HOME=${AEM_HOME:=/opt/aem}
export NATIVE_SERVICE_PORT=${NATIVE_SERVICE_PORT:=8007}
export NATIVE_METRICS_PORT=${NATIVE_METRICS_PORT:=8008}
export AZURITE_BLOB_PORT=${AZURITE_BLOB_PORT:=10000}
export AZURITE_QUEUE_PORT=${AZURITE_QUEUE_PORT:=10001}
## END CONFIGURABLE ENVIRONMENT VARIABLES ##

### Main script begin
source hsm.properties

# These directories must exist and be writable for the docker user
export AEM_FONTS_DIR=$AEM_HOME/crx-quickstart/fonts
export AEM_LOGS_DIR=$AEM_HOME/crx-quickstart/logs
export SDK_TEMP_DIR=$AEM_HOME/crx-quickstart/temp/sdk

# Defer export until necessary
CUSTOM_FONTS_DIR=$AEM_HOME/crx-quickstart/fonts_user

# This is the mount point of SDK_TEMP_DIR in the container
export SHARED_TEMP_DIR=/mnt/shared/temp

# forms-native-sdk image
export FORMS_NATIVE_SDK_IMAGE_FILE=${forms-native-sdk.image.name}-${forms-native-sdk.image.tag}.tar.gz
export FORMS_NATIVE_SDK_IMAGE_NAME=${forms-native-sdk.image.repo}/${forms-native-sdk.image.name}:${forms-native-sdk.image.tag}

# forms-java-sdk image
export FORMS_JAVA_SDK_IMAGE_FILE=${forms-java-sdk.image.name}-${forms-java-sdk.image.tag}.tar.gz
export FORMS_JAVA_SDK_IMAGE_NAME=${forms-java-sdk.image.repo}/${forms-java-sdk.image.name}:${forms-java-sdk.image.tag}

export FORMS_JAVA_SDK="docker-compose.hsm.yml"
export CUSTOM_FONT_SUPPORT="docker-compose.customfont.yml"

function usage() {
  echo "Usage: sdk.sh [start | stop]"
  exit
}

function checkWritable() {
  dir=$1
  if [ ! -d "$dir" ]; then
    echo "Error: $dir does not exist"
    exit 1
  else
    echo "Found $dir, making writable ..."
    if ! chmod -R a+rw "$dir"; then
      echo "Could not make $dir writable, exiting ..."
      exit 1
    fi
  fi
}

function load_image() {

  image_file=$1
  image_name=$2

  echo "Loading $image_name ..."
     if ! docker load < "$image_file"; then
       echo "Error: $image_name could not be loaded, exiting ..."
       exit 1
     fi
     echo "$image_name loaded"

}

function start_sdk_composition() {
    compose_files=$1
    if [ ! -d "$CUSTOM_FONTS_DIR" ]; then
        if ! docker-compose $compose_files up -d; then
            echo "Error: SDK could not be started, exiting ..."
            exit 1
        fi
    else
        checkWritable $CUSTOM_FONTS_DIR
        export CUSTOM_FONTS_DIR
        echo "Found custom fonts at $CUSTOM_FONTS_DIR"
        if ! docker-compose $compose_files -f $CUSTOM_FONT_SUPPORT up -d; then
            echo "Error: SDK could not be started, exiting ..."
            exit 1
        fi
    fi
}

function start_sdk() {
    # Check and make required directories writable
    checkWritable "$AEM_FONTS_DIR"
    checkWritable "$AEM_LOGS_DIR"

    if [ ! -d "$SDK_TEMP_DIR" ]
    then
      mkdir -p $SDK_TEMP_DIR
    fi
    checkWritable $SDK_TEMP_DIR

    # Check whether HSM IP is specified in hsm.properties
    hsm_server_ip_uncommented=$(grep -v '^#' hsm.properties | grep 'aws_hsm_server_ip' | awk -F'=' '{ip=$2} END {print ip}')
    if [ -n "$hsm_server_ip_uncommented" ]; then
        VPN_TEST_HOST=$hsm_server_ip_uncommented
        echo "HSM server set to $VPN_TEST_HOST, checking connectivity ..."
        echo "Pinging $VPN_TEST_HOST to check for VPN connectivity ..."
        ping -c 1 $VPN_TEST_HOST > /dev/null 2>&1

        if [ $? -eq 0 ]; then
            echo "$VPN_TEST_HOST is reachable, VPN connection test successful."
        else
            echo "$VPN_TEST_HOST appears to be unreachable, check whether VPN connection is active."
        fi

        start_sdk_composition "-f docker-compose.yml -f $FORMS_JAVA_SDK"
    else
        echo "HSM server undefined, starting SDK without HSM support ..."
        start_sdk_composition ""
    fi

    echo "SDK started successfully"
}

function stop_sdk() {
  echo "Stopping SDK ..."
  if [ -d "$CUSTOM_FONTS_DIR" ]; then
    checkWritable $CUSTOM_FONTS_DIR
    export CUSTOM_FONTS_DIR
    if ! docker-compose -f docker-compose.yml -f $FORMS_JAVA_SDK -f $CUSTOM_FONT_SUPPORT down -v; then
      docker ps
      echo "Error: Could not stop SDK, some containers may still be running ..."
      exit 1
    fi
  else
    if ! docker-compose -f docker-compose.yml -f $FORMS_JAVA_SDK down -v; then
      docker ps
      echo "Error: Could not stop SDK, some containers may still be running ..."
      exit 1
    fi
  fi
  echo "SDK stopped successfully"
}

case "$1" in
  start)
    load_image "$FORMS_JAVA_SDK_IMAGE_FILE" "$FORMS_JAVA_SDK_IMAGE_NAME"
    load_image "$FORMS_NATIVE_SDK_IMAGE_FILE" "$FORMS_NATIVE_SDK_IMAGE_NAME"
    start_sdk
    ;;
  stop)
    stop_sdk
    ;;
  *)
    usage
    ;;
esac
