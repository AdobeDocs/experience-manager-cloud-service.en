# Locale dictionary project-source example

This archive is integration source, not an installable AEM package, a full
Maven project, or a complete Arabic form. It includes no prebuilt installer,
test forms, credentials, or submitted form data.

## Files

- `ui.apps/.../clientlib-locale-ar-ae/.content.xml`: client library category,
  runtime dependency, and proxy setting.
- `ui.apps/.../clientlib-locale-ar-ae/js.txt`: loader inclusion.
- `ui.apps/.../clientlib-locale-ar-ae/js/languageinit.js`: locale callback.
- `ui.apps/.../clientlib-locale-ar-ae/resources/i18n/ar-ae.json`: full
  untranslated English template from Core Forms Components 1.1.78.
- `ui.config/.../Guide Localization Service.cfg.json`: example locale list.
- `snippets/required-message.ar-ae.json`: illustrative Arabic required-field
  message only; NOT a complete dictionary.
- `LICENSE` and `NOTICE`: Apache-2.0 license and source attribution.

## Integrate into your project

1. Follow the official Core Components locale setup guide:
   https://experienceleague.adobe.com/en/docs/experience-manager-cloud-service/content/forms/adaptive-forms-authoring/authoring-adaptive-forms-core-components/create-an-adaptive-form-on-forms-cs/supporting-new-language-localization-core-components
1. Copy the client library source into your project's `ui.apps` module.
   Replace `myproject` in paths, category, and loader URL with your application
   ID. Ensure your existing package filters include the client library.
1. Merge `ar-ae` into your existing Guide Localization Service configuration
   in `ui.config`. Preserve ALL existing supported locale values. This example
   list must not overwrite your project's list. Keep the JSON valid and use
   your project's applicable configuration location/run modes.
1. Follow the setup guide for `/etc/languages` when required. Preserve its
   existing values and use your project's content packaging. This source
   archive does not supply or overwrite that server-wide content.
1. Retrieve `en.json` from the runtime installed in your target environment:
   `/etc.clientlibs/core/fd/af-clientlibs/core-forms-components-runtime-all/resources/i18n/en.json`.
   Compare the complete key set and structure, including nested entries, with
   the bundled 1.1.78 template. Add/version-match keys as needed and translate
   every value into your target language, preserving keys and placeholders
   such as `${0}`. The bundled `ar-ae.json` is still English.
1. The illustrative snippet shows a translated `required` value. Merge that
   value into the complete translated dictionary if appropriate; do not use
   the snippet as the deployed dictionary. Review translations for your users.
1. Add `myproject.forms.locale.ar-ae` (or your renamed category) to the form
   container's **Client library category** setting. The loader handles only
   the exact `ar-ae` value; this is an example guard, not a claim about locale
   normalization rules. Adjust it for the languages your project handles.
1. Translate authored labels through the form dictionary/translation-project
   workflow. A runtime dictionary covers built-in messages and is not proof
   that every date, number, or currency format is localized.
1. Build and deploy through your existing project's documented deployment
   process and Cloud Manager pipeline. Do not try installing this source ZIP
   through Package Manager. No build command is supplied because this archive
   is not a standalone build.

## Verify

Open the form with `?afAcceptLang=ar-ae` (or append `&afAcceptLang=ar-ae` to an
existing query). Check the model JSON's `lang`, the project dictionary request
URL/status and JSON, and callback execution. Wait for language initialization
before inspecting:

```javascript
FormView.LanguageUtils.getTranslatedString('ar-ae', 'required')
guideBridge.validate()
```

Confirm the returned value and displayed required-field message match your
translated dictionary. A successful HTTP request alone does not establish
that a translation is used. Retest relevant existing locales; the example
callback must not load its dictionary for other locales.

## Provenance and verification limits

The loader adapts Adobe's Apache-2.0 sample at release
`core-forms-components-reactor-1.1.78`, commit
`00e71c9175f1304d325bbb5f519c310bdead3750`. The full dictionary template is an
unmodified copy of that release's `en.json`, renamed `ar-ae.json`. It is NOT
labeled as a 3.0.172 dictionary. See NOTICE for exact upstream paths.

Earlier source-example checks on AEM 6.5 SP25 and LTS SP3 with Core Forms
Components 1.1.78 simulated server locale JSON; they did not establish
end-to-end ar-ae rendering. A later local Cloud Service SDK check with Forms
2026.10.6.04 and Core Components 3.0.172 confirmed locale registration,
custom-dictionary loading, and a translated required-field message. The
built-in ar-ae dictionary request returned 404 while the custom dictionary
returned 200 and worked.

That test does not certify this source archive as a complete deployment,
all translated messages/formats, missing-key fallback behavior, locale
precedence/normalization, or hosted delivery through Dispatcher/CDN.

Review and redact logs and screenshots before sharing diagnostics. Exclude
credentials, tokens, cookies, and submitted form data from support artifacts.
