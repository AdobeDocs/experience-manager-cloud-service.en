/*******************************************************************************
 * Copyright 2023 Adobe
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

// Adapted sample: project URL, exact locale guard, and returned load promise.
(function () {
    "use strict";
    var LOCALE_CODE = "ar-ae";
    var DICTIONARY_URL = "/etc.clientlibs/myproject/clientlibs/clientlib-locale-ar-ae/resources/i18n/" + LOCALE_CODE + ".json";

    function onInit(guideBridge) {
        guideBridge.registerConfig(guideBridge.ConfigKeys.LOCALE_CONFIG, function (lang) {
            if (lang !== LOCALE_CODE) {
                return;
            }
            return window.FormView.LanguageUtils.loadLang(lang, DICTIONARY_URL);
        });
    }

    function onBridgeStart(event) {
        onInit(event.detail.guideBridge);
        window.removeEventListener("bridgeInitializeStart", onBridgeStart);
    }

    if (window.guideBridge) {
        onInit(window.guideBridge);
    } else {
        window.addEventListener("bridgeInitializeStart", onBridgeStart);
    }
})();
